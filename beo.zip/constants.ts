
export const COLORS = {
  main: '#ffe1cc',
  secondary1: '#ffe1cc',
  secondary2: '#ea8a68',
  third: '#ffc0cb',
  buttonText: 'rgb(5, 46, 67)'
};

export const ASSETS = {
  background: 'https://optways.net/wp-content/uploads/2026/01/bg-main.jpg',
  item1: 'https://optways.net/wp-content/uploads/2026/01/item-bg-1.png',
  item2: 'https://optways.net/wp-content/uploads/2026/01/item-bg-2.png',
  scene1Main: 'https://optways.net/wp-content/uploads/2026/01/title.svg',
  catSelf: 'https://optways.net/wp-content/uploads/2026/01/banthan.svg',
  catHealth: 'https://optways.net/wp-content/uploads/2026/01/suckhoe.svg',
  catCareer: 'https://optways.net/wp-content/uploads/2026/01/sunghiep.svg',
  finalPhoto: 'https://optways.net/wp-content/uploads/2026/01/beo-demo-1.png',
  gift: 'https://optways.net/wp-content/uploads/2026/01/gift.svg',
  titleFinal: 'https://optways.net/wp-content/uploads/2026/01/title-fnl.svg',
  cake: 'https://optways.net/wp-content/uploads/2026/01/cake.svg'
};

export const WISHES = {
  self: "Chúc chị Nguyện lúc nào cũng rực rỡ, xinh tươi, tràn đầy niềm vui với những gì mình làm, mình yêu nhé! 🥰",
  health: "Sức khoẻ là quan trọng nhất đúng ko neeeeeeè - Chúc chị mình luôn khỏe về thể chất cũng như tinh thần, để cùng em Bon đi du lịch muôn nơi mà không biết mệt nhé! 😌",
  career: "Mong những điều ấp ủ, những dự định về công việc của béo chắc chắn thành hiện thực vì B tin rằng chị của mình một khi đã vào việc thì sẽ thành công 😎 ĐÁNH ĐÂU THẮNG ĐÓ – TIỀN VÀO NHƯ NƯỚC – ÁP LỰC NHƯ MÂY"
};
